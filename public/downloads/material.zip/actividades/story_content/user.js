function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Cz3KrhN4bS":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

